    	Udacity Self Driving Car Nanodegree � 
Project: Advanced Lane Finding





By:
Saurabh Sohoni
Udacity profile: https://profiles.udacity.com/p/u183059

Contents
1.	INTRODUCTION	3
2.	PROJECT GOALS	3
3.	IMPLEMENTATION OF PROJECT RUBRIC POINTS	3
3.1	WRITE UP / README	3
3.2	CAMERA CALIBRATION	3
3.3	PIPELINE ON TEST IMAGES	4
3.4	PIPELINE ON VIDEO	12
3.5	DISCUSSION	12
4.	REFERENCES	13



































1. Introduction
This document acts in support with code and output files created in order to implement �Advanced Lane Finding� project. In this project, a pipeline is created to detect right and left lanes lines and their curvature in an image with the help of image processing techniques. A camera mounted on the hood of the vehicle in center records path ahead of a car. Project pipeline created in this project is then applied to this video recording to detect lane area in which the car must drive along with the curvature of road.
2. Project Goals
Following were the goals of this project:

a. Calculate camera calibration and distortion coefficients with the help of 20 chessboard images. This calibration is then used to correct distortion in distorted images taken by the same camera mounted on hood of a car.
b. Apply distortion correction to sample distorted images and verify the results.
c. Make use of image gradients to detect edges in an image. This detection will help in extracting lane lines in an image.
d. Apply color threshold to various color planes (for e.g.: R, G and B in an RGB image) and explore into other color spaces (such as HLS, HSV, YCbCr) to effectively detect white and yellow lane lines in an image.
e. Apply perspective transform to get a bird�s eye view of detected lane markers in an image. Characteristics such as radius of curvature of road and centroid of lane area can be extracted from transformed image.
f. Implement sliding window search to separate out lane lines from perspective transformed image. Fit these detected lane lines to two second degree polynomials (one for left lane marker and other for right lane marker) and extract area between them.
g. From the lane lines detected using sliding window, calculate the radius of curvature of road and position of vehicle w.r.t. center of lane area.
h. Draw lane detected area back to original image captured by camera to map lane lines and area between them. Also annotate the image with radius of curvature of road and vehicle position w.r.t. center of lane area.
i. Summarize the approach and results in a report.
3. Implementation of Project Rubric Points
Following section lists down various rubric points for this project and also details out the implementation strategy followed:

3.1 Write up / README

This report lists methodology used in creation of lane detection pipeline and supports the code written for various python methods used in this project.



3.2 Camera Calibration

A camera installed on the hood of the car is used to capture images of road and scene in the front. To calibrate this camera, Udacity had provided with 20 calibration images captured by the same camera with the same setup. These were the images of a 9 x 6 (9 columns and 6 rows) chessboard taken from different angels. Camera calibration was achieved by following the steps given below:

1. Object points on a chessboard in the real world were created. Object points are nothing but points in 3 dimensional space (x, y, z) on a chessboard placed in 3D world. In the scope of this project, it was assumed that chessboard, with size of 9 x 6, used for taking images was placed on a flat surface. Hence, z was 0 for all object points. The object points then looked like (0, 0, 0), (0, 1, 0) up to (5, 8, 0).

2. Each calibration image taken as input was searched to find chessboard corners. If the corners are found, these corners were used as the image points. An example is shown below:


Figure 1a is one of the calibration images. Chessboard corners found on this image are drawn with different colors.

3. Step 2 is repeated for all of the calibration images and a list of detected image points in formed. Object point are same for every image, hence, are duplicated and appended to a list object points for each image in which image points were found.
4. Lists of image points and object points are then used to generate camera matrix and distortion coefficients. These coefficients were used in next step to correct distortion in images.

Python code for camera calibration can be found in calculate_camera_calibration() method in project pipeline.


3.3  Pipeline on Test Images

Lane finding pipeline comprised of several steps as described below:

3.3.1 Distortion Correction (Undistort images)
		
Image capture in modern cameras taken place with the help of lenses. As a result, such a camera does not follow �Pinhole camera model� [1]. This may introduce tangential and radial distortion in the images captured under certain conditions. To correct this type of distortion, camera matrix and distortion coefficients calculated in camera calibration steps are used to obtain undistorted images as output. An example with a chessboard image and image taken on a road is shown below:



Python code for distortion correction can be found in undistort() method in project pipeline.

3.3.2 Image Gradient and Color Thresholding
		
Detection of lane lines starts with detecting edges and identifying continuous white and yellow lines. Edge detection is achieved by calculating gradients in an image and information on colored lines can be extracted using color thresholding on different color planes in different color spaces. This is described below:

1. Image gradients:

Image gradients are nothing both Sobel derivatives taken either across horizontal (X) axis or vertical (Y) axis or both in an image. These gradients are useful in detecting edges around lane lines. Since lane lines are almost vertical, this project used gradient along x direction (gradx). Also, the magnitude of combined gradient (mag) is useful to make lane lines prominent and add weight to them against other edges in the image. In this project, information about edges obtained from gradx and mag images was combined to obtain an image with lane lines. An example is shown below:


Python code for obtaining these gradients can be found in sobel_threshold(),magnitude_threshold() and apply_grad_threshold() methods in the pipeline. For obtaining gradx, sobel kernel of shape 11 x 11 was used with pixels in the range [40, 150] retained. For obtaining mag, sobel kernel of shape 11 x 11 was used with pixels in the range [50, 150] retained.

2. Thresholding in RGB and HLS color spaces:

Image gradients work fine in lane lines detection when the lane lines are brighter than other background pixels in the image. This is the reason gradients fail in detection of yellow lane lines as yellow is mapped to less bright pixels when converted from RGB to gray. Also, gradients fail in case a shadow is cast on the road as edges cannot be detected accurately.
			
Problems mentioned above can be overcome by using color thresholds in RGB and HLS images. White lane lines are detected accurately by using pixels belonging to the range [220, 255] in Red (R) channel of an RGB image. This is shown below:




As evident from the result, R channel picks the white lane line effectively even in the presence of shadow. But it fails to detect yellow colored lane line.

S channel of Hue, Lightness, Saturation (HLS) color space [2] is invariant to brightness in the image. Hence, pixels belonging to [160, 200] values in S channel are used to pick yellow lane lines in the image. This is demonstrated in example below:



In this project, information obtained from R and S channel thresholded images was combined to get an image with lane lines. An example is shown in the combined image above.
			
Python code for obtaining these color thresholds can be found in apply_color_threshold() method in the pipeline.

3. Merged gradient and color thresholded image:

Finally, characteristics obtained from combined gradient and combined color thresholded images were merged to obtain a gray scale image with lane lines detected prominently. Example of such an image is shown below:


Python code for obtained combined gradient and color thresholded image can be found in the method detect_lane_lines() in the pipeline.



3.3.3 Perspective transform to get a bird�s eye of lane lines
		
Lane lines detected by techniques described above don�t provide much information on the curvature of road. Also, parallel lane lines appear to converge in a 2D image due to phenomenon of image perspective [3]. To get some information on the lane curvature, lane detected binary images are warped to get a bird�s eye view of the lane lines somewhat similar to the one shown in example below:


Perspective transform is obtained by choosing a polygon in lane image and mapping it to a rectangle over entire dimension of an image. Details on polygon chosen in this project is mentioned above in the image caption.

Python code for implementation of perspective transform can be found in the apply_perspective_transform() method in the pipeline.

3.3.4 Identification of Lane lines in warped image

As shown above, warped image is a binary and has lane line markers in bottom 70% of pixels in Y axis. Lane lines are white and can be detected by looking for non-zero pixels. To detect left and right lane lines and fit them to a second degree polynomial, sliding window technique was used. In this technique, initial guess on locations of lane lines is done by taking a histogram over bottom 70% pixels in Y axis of the warped image. Such a histogram is shown below:




The two prominent peaks in left half and right half of the histogram are nothing but the locations of lane lines. The sliding window algorithm starts from bottom of warped image at locations (hist_peak_left, image_y_size) and (hist_peak_right, image_y_size) for left and right lanes respectively. Then the algorithm goes on detecting non-zero pixels in the boundary of the window and draws number of windows until it reaches the top of the image. In this process, the algorithm caches pixel coordinates and then fits them to a second degree polynomial each for the left and the right lane respectively. This is shown in the example below:


Figure 8: Sliding window search detects lane lines and fits them to polynomial [9r]


In this project, the size of window was chosen to be 100 in X axis and number of sliding windows to be 10. Also, if a cluster of 2000 non-zero pixels is detected during the search, this algorithm shifts takes the centroid of those pixels and draws a window accordingly.


Python code for implementing sliding window search can be found in sliding_window_search() method in the pipeline. Most of the code was reused and is attributed to code made available in class [4] by Udacity.

3.3.5 Radius of Curvature and Vehicle Position
		
For a curve represented by the function y = f(x), the radius of curvature can be calculated using the formula given below [5]:

		
Left and right lane lines detected in above section were each fitted to a second degree polynomial. A generic second degree polynomial can be represented by:

		y = f(x) = Ax2 + Bx + C ; 	A, B, C being constants
		
		And the first and second order derivatives are given by:

		(dy/dx) = 2Ax + B

		(d2y/dx2) = 2A
		
		Hence, the radius of curvature is given by:

		Rcurve = (1 + (2A + B)2 )3/2 / |2A|

For the position of the vehicle, it is assumed that the camera is mounted at the center of the car. The deviation of the midpoint of the center of the image from the center of the lane is the relative position of vehicle in the lane area.
The center or centroid of lane area is calculated by calculating moments of curve.

The radius of curvature and vehicle position thus obtained is in pixel space and needs to be converted to meters space. This was done with an approximation that lane is about 30 meters long and 3.7 meters wide adhering to US regulations [6] that require a minimum lane width of 12 feet or 3.7 meters.

Python code for calculating radius of curvature and position of vehicle can be found in extract_radius() and advanced_lane_detection() methods respectively. Code for detection of radius of curvature is reused and is attributed to code made available in class [7] by Udacity.



3.3.6 Result Image with Marked Lane Lines

In this last step of the pipeline, area enclosed by left and right lane lines is filled with dark green color to form an image in bird�s eye view. This image is then warped back to original image captured by camera by taking inverse of perspective transform. Resulting images are shown below:



Python code for warping lane lines back to original camera image can be found in warp_lanes() method. This code is reused and is attributed to code made available in class [8] by Udacity.

3.4 Pipeline on Video

The pipeline created for testing on images is then applied to a video (project_video.mp4) taken around a freeway, provided by Udacity. 

VideoFileClip utility from moviepy,editor Python library was used to extract image frames from the video. Pipeline applied to every frame was able to detect lane lines, area bounded by lane lines, radius of curvature of road and vehicle position effectively. The resulting video is saved in output_video folder submitted along with this document.

3.5 Discussion

3.5.1 Challenges faced
	
One big challenge faced during implementation was coming out with lower and upper thresholds for applying color thresholding to lane images. With different lighting conditions seen in test images, no unique limit value worked on all the images. This challenge was overcome with the help of information from image gradients. A combined image could detect lane lines effectively.

3.5.3 Scenarios resulting in failure of pipeline
	
       Following are a few of scenarios where the pipeline created currently may fail:
	
1. Lane search technique used in this pipeline makes a guess of lane lines from the histogram of binary warped image. If this initial guess fails, the whole algorithm will fail.

2. Current algorithm is pipeline assumes that both left and right line will be detected and a second degree polynomial will be fit to each one of the lines. But in case the dashed lane lines are not seen, the whole logic of determining area bounded by lane lines will fail.

3. On country roads where lane lines are not bright enough, edge detection and color threshold will fail to detect lane lines effectively.

4. In winters, when snow is covered on some areas of road, it is very difficult to apply color thresholding techniques as snow is white in color.

3.5.3 Solution to challenges and carving a robust pipeline

To avoid failure of pipeline in scenarios mentioned above, few algorithms given below should be used along with existing pipeline:
	
1. An educated guess on initial position of lane lines can be made by caching last few lane line positions and comparing the current search. If a lot of deviation is found, the algorithm can fall back to lines detected in previous frame.
2. In case one of the lane lines is not found, either the algorithm should revert to lane lines found in last image frame or try to extrapolate behavior of missing lane from the one found.
3. In case of country roads, an assumption can be made that the road is narrow enough to accommodate only one vehicle. Hence the car can remain in the same lane forever and look ahead for surrounding obstacles using lasers or LIDARS.













4. References
1. [1] Pinhole camera model
2. [2] HLS and HSV color space
3. [3] Image Perspective
4. [4]  Lane lines detection by using sliding window search in Python
5. [5] Radius of curvature
6. [6] US government specifications for highway curvature 
7. [7] Extracting radius of curvature from second degree polynomial in Python
8. [8] Visualizing area bounded by lane lines in Python
9. [9] Image references:
a. /examples/camera-calibration.JPG
b. /examples/chessboard-corners.JPG
c. /examples/chessboard-distorted-image.JPG
d. /examples/chessboard-distortion-corrected-image.JPG
e. /examples/road-distorted-image.JPG
f. /examples/road-distortion-corrected-image.JPG
g. /examples/road-image-for-gradient-thresholding.JPG
h. /examples/gradx-gradient-image.JPG
i. /examples/mag-gradient-image.JPG
j. /examples/merged-gradient-image.JPG
k. /examples/road-image-for-color-thresholding.JPG
l. /examples/r-channel-thresholded-image.JPG
m. /examples/s-channel-thresholded-image.JPG
n. /examples/r-and-s-channel-combined-image.JPG
o. /examples/merged-gradient-and-color-image.JPG
p. /examples/perspective-birds-eye-view-image.JPG
q. /examples/histogram.JPG
r. /examples/sliding-window-search.JPG
s. /examples/area-enclosed-by-lanes.JPG
t. /examples/ lane-area-and-annotated-image.JPG


