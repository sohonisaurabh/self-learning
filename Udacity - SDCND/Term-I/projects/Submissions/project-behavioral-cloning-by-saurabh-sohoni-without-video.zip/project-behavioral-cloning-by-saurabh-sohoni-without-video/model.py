#Imports for python modules
import csv
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Flatten, Dense, Activation, BatchNormalization, Dropout
from keras.layers.convolutional import Convolution2D
from keras.layers.pooling import MaxPooling2D
from keras.optimizers import Adam
import cv2
import numpy as np

#Global variables declaration and definition
data_path = "recorded-data"
generator_batch_size = 100
steering_offset = 0.25
model_name = "model.h5"

#====================================================Utility methods declaration and definiton starts here====================================================

###
# This method is used for reading lines from driving_log.csv. This is the training data containing steering angle values for corresponding image of world seen
# by the car.
###
def load_lines(path):
    lines = []
    with open(path + "/driving_log.csv") as datafile:
        reader = csv.reader(datafile)
        for line in reader:
            lines.append(line)
    return lines
###
# This method is used for extracting center, left and right image from IMG folder given the path of respective image.
###
def extract_images(line):
    #In windows system, paths are separated by "/" while in a Linux system by a "\". Hence, all "\" are first converted to "/" before extracting image name.
    center_image = cv2.imread(data_path + "/IMG/" + line[0].replace("\\", "/").split("/")[-1])
    left_image = cv2.imread(data_path + "/IMG/" + line[1].replace("\\", "/").split("/")[-1])
    right_image = cv2.imread(data_path + "/IMG/" + line[2].replace("\\", "/").split("/")[-1])
    return (center_image, left_image, right_image)

###
# This method is used reading steering angle from a line from driving_log.csv. Here, steering values are positive if car steers to right and negative if car
# steers to the left.
###
def extract_steering_angles(line):
    steering_angle_center = float(line[3])
    #Add steering_offset for left camera image to steer more to the right
    steering_angle_left = steering_angle_center + steering_offset
    #Subtract steering_offset for left camera image to steer more to the right
    steering_angle_right = steering_angle_center - steering_offset
    return (steering_angle_center, steering_angle_left, steering_angle_right)

#====================================================Utility methods declaration and definiton ends here====================================================

#====================================================Methods used in data Pre-pocessing are declared here====================================================

###
# This method is used cropping images taken by car's camera to remove background scenery and retain only region around lane lines in an image. Nearly top 40%
# of image in y-axis is removed to avoid interference of background features in training data.
###
def crop_image(image):
    mask = np.ones_like(image)
    xsize, ysize = image.shape[1], image.shape[0]
    vertices = ((0, 0.4375*ysize), (0, ysize), (xsize, ysize), (xsize, 0.4375*ysize))
    vertexArr = []
    for vertex in vertices:
        vertexArr.append((vertex[0], vertex[1]))
    vertexArr = np.array([vertexArr], dtype=np.int32)
    
    cv2.fillPoly(mask, vertexArr, (255, 255, 255))
    masked_image = cv2.bitwise_and(image, mask)
    return masked_image

###
# This method is used resizing images to 160x80 (width x height) as this size is sufficient for input image to training architecture used. Also, bigger size
# images are take more memory and time while training, with not much effect on training accuracy.
###
def resize(image, size=(160, 80)):
    resized_image = cv2.resize(image, size) 
    return resized_image

###
# This method is used for flpping images around vertical axis.
###
def flip_vertical(image):
    flipped_image = cv2.flip(image, 1)
    return flipped_image

#====================================================Methods used in data Pre-pocessing are end here=========================================================

#====================================================Define generator and model architecture=================================================================


#====================================================Definition of generator and model architecture ends here=================================================

###
# This method is used for creating a python generator which returns 300/600 images (depending on whether flipping of images is used) in an epoch.
###
def get_data_generator(lines, generator_batch_size=100, flip_images=True):
    offset = 0
    #Shuffle data in the beginning of training epoch
    shuffled_lines = shuffle(lines)
    while 1:
        images = []
        steering_angles = []
        line_batch = shuffled_lines[offset : offset + generator_batch_size]
        for line in line_batch:
            #Extract images from paths
            center_image, left_image, right_image = extract_images(line)
            #Convert images to yuv color plane
            #center_image, left_image,right_image = convert_to_yuv(center_image), convert_to_yuv(left_image), convert_to_yuv(right_image)
            #Resize images to 160 x 80 dimension
            center_image, left_image,right_image = resize(center_image, (160, 80)), resize(left_image,(160, 80)), resize(right_image, (160, 80))
            #Crop the top portion of images to remove unwanted background scenery
            center_image, left_image,right_image = crop_image(center_image), crop_image(left_image), crop_image(right_image)
            #Extract steering angles for 
            steering_angle_center, steering_angle_left, steering_angle_right = extract_steering_angles(line)
            #Add images and corresponding steering angles and extend their storage arrays
            images.extend([center_image, left_image, right_image])
            steering_angles.extend([steering_angle_center, steering_angle_left, steering_angle_right])

            #Flip images vertically if flip_images is true.
            if (flip_images):
                center_image, left_image,right_image = flip_vertical(center_image), flip_vertical(left_image), flip_vertical(right_image)
                steering_angle_center, steering_angle_left, steering_angle_right = (steering_angle_center*-1), (steering_angle_left*-1), (steering_angle_right*-1), 
                images.extend([center_image, left_image, right_image])
                steering_angles.extend([steering_angle_center, steering_angle_left, steering_angle_right])
            
        offset += generator_batch_size
        if (offset >= len(lines)):
            offset = 0
            shuffled_lines = shuffle(lines)
        yield (np.array(images), np.array(steering_angles))

###
# This method is used for declaring training architecture. In this project, NVIDIA's End to end learning for self driving cars model
###
def train_model_nvidia(training_generator, validation_generator, nb_training, nb_validation, epochs=10, use_generator=True, model_name="model.h5"):
    #Define layers used in model architecture
    model = Sequential()
    model.add(BatchNormalization(input_shape=(80, 160, 3)))
    model.add(Convolution2D(24, 5, 5, border_mode='valid', subsample=(2,2), activation="relu", bias=True, init="uniform"))
    model.add(Convolution2D(36, 5, 5, border_mode='valid', subsample=(2,2), activation="relu", bias=True, init="uniform"))
    model.add(Convolution2D(48, 5, 5, border_mode='valid', subsample=(2,2), activation="relu", bias=True, init="uniform"))
    model.add(Convolution2D(64, 3, 3, border_mode='valid', subsample=(1,1), activation="relu", bias=True, init="uniform"))
    model.add(Convolution2D(64, 3, 3, border_mode='valid', subsample=(1,1), activation="relu", bias=True, init="uniform"))
    model.add(Flatten())
    model.add(Dense(100, bias=True, init="uniform"))
    model.add(Activation("relu"))
    model.add(Dropout(0.5))
    model.add(Dense(50, bias=True, init="uniform"))
    model.add(Activation("relu"))
    model.add(Dropout(0.5))
    model.add(Dense(1, bias=True, init="uniform"))
    model.compile(loss="mse", optimizer="adam")
    #This model was tested with and without the use of python generators
    if use_generator:
        model.fit_generator(training_generator, validation_data=validation_generator, nb_epoch=epochs, samples_per_epoch=nb_training, nb_val_samples=nb_validation)
    else:
        model.fit(training_generator[0], training_generator[1], validation_split=0.2, shuffle=True, nb_epoch=epochs)
    #Save the model
    model.save(model_name)
    
#====================================================Definition of generator and model architecture ends here=================================================


#====================================================Main method used for running the network for provided training data======================================
def main(model_name):
    lines = load_lines(data_path)[1:]
    training_set_lines, validation_set_lines = train_test_split(lines, test_size=0.2)

    #Since flpping of images is used by default, the number of images are 6 times the number of lines in driving_log.csv
    nb_training = len(training_set_lines)*6
    nb_validation = len(validation_set_lines)*6

    training_generator = get_data_generator(training_set_lines, generator_batch_size=generator_batch_size)
    validation_generator = get_data_generator(validation_set_lines, generator_batch_size=generator_batch_size)
    
    train_model_nvidia(training_generator, validation_generator, nb_training, nb_validation, epochs=3, use_generator=True, model_name=model_name)
    
#Set the datapath and model name here before uncommenting call to main()
data_path = "D:/Udacity_SDCND/project-3-data/bridge-data-collection"
model_name = "model-merged-dropout-relu-flip-data.h5"
main(model_name)
